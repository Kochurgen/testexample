(function($) {
       var _firstTimeAttach,
           _pageController,
           adapter = {
        getPageCount: function () {
            return 5;
        },
        setPageContent: function (position, rootElement) {
            rootElement.innerHTML = "<div class='inn'>index: " + position + "</div>";
            rootElement.setAttribute('index', position);
        }
    };
    function Init() {
        if (_firstTimeAttach) {
            if (_pageController) {
                _pageController.destroy();
            }
            _firstTimeAttach = false;
            _pageController = new Pager(document.getElementById('view'), adapter);
        }

    }
    $(function () {
        _firstTimeAttach = true;
        Init();
    });
})(jQuery);

