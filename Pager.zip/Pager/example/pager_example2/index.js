(function($) {
       var _firstTimeAttach,
           _pageController,
           _pointerTracker,
           content,
           text,
           adapter = {
        el: 'div',

        getPageCount: function () {
            return 5;
        },
        setPageContent: function (position, rootElement) {
            rootElement.innerHTML = '<div>' + position + '<div><div class="inn">'+ content[position]+ '<div>';
            rootElement.setAttribute('index', position);
        }
    };

    function Init() {
        if (_firstTimeAttach) {
            if (_pageController) {
                _pageController.destroy();
            }
            _firstTimeAttach = false;
            _pageController = new Pager(document.getElementById('view'), adapter);
            _pointerTracker = new PointerTracker(document.body);
        }
        text = _pageController._adapter.getPageCount()-1;
        $('#page_counter').val("Total pages: " + text);
        $('#current_page').val('0');
        $('#go_to_page').on('click',function(){
           _pageController.gotoPage($('#current_page').val());
        })
    }
    $(function () {
        _firstTimeAttach = true;
        $.getJSON("content.json", function(result){
               content=result;
            Init();
        });


    });
    $(document).ready(function(){
    })
})(jQuery);


