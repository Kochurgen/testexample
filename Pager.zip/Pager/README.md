#Pager

implementation of a management tool display pages and pagination.

Unlike other libraries, **Pager** let you just expand your app slider with pagination.
The only drawback is the lack of browsers other than IE11 mouse events (pointerop, pointerdovn, pointermove, pointerover, pointerkantсel), noon solved connection library [Pointer](https://github.com/Rapid-Application-Development-JS/Pointer)

###Methods

#### Create object
```javascript
  var _pageController = new Pager(element, adapter, options)
```
Takes the DOM element **element** as the container pager. The DOM should contain this element.

Takes the object **adapter** is any object in which the pager will be displayed. **adapter** must contain functions:
- **getPageCount** - this function must return quantity of pages
- **setPageContent** -this function must add conetnt to **element**. function takes the following parameters:
    - **rootElement** - page handler
    - **position** - page number

Takes the object **options** as the parameter. The object has the following properties:
* **onSwipeEnd** - function which is processing ending swipe
* **preventMove** - Enable support of native vertical scrolling in Android
* **resizeEvent** - resize handler pages when resizing view.

default value **options**:

```javascript
	{
		preventMove: true,
		resizeEvent: true
	}
```
### Tap-events
Pager provide tap-events for DOM elements:
-fling
-pointerup
-pointermove
-pointerdown
-pointercancel

**Warning:** Your widgets should broadcast next events for correct work of module `Pager`:
- pointerup
- pointerdown
- pointermove
- pointerover
- pointercancel

Now this events have native support only in IE 11 and newer versions.
You have to use mouse event wrapper that provides needed events for working with others browsers. We recommend use our wrapper
[Pointer](https://github.com/Rapid-Application-Development-JS/Pointer)

navigation metods:
**currentPage** - page currently active
**gotoPage** - jump to a particular page. The function has the following properties:
- **number** - number page

**swipeTo** - swipe to next or previous page.The function has the following properties:
-**direction** - is set to swipe direction('left' or 'right')

**Example**
```javascript
 (function($) {
       var _firstTimeAttach,
           _pageController,
           adapter = {
        getPageCount: function () {
            return 5;
        },
        setPageContent: function (position, rootElement) {
            rootElement.innerHTML = "<div class='inn'>index: " + position + "</div>";
            rootElement.setAttribute('index', position);
        }
    };
    function Init() {
        if (_firstTimeAttach) {
            if (_pageController) {
                _pageController.destroy();
            }
            _firstTimeAttach = false;
            _pageController = new Pager(document.getElementById('view'), adapter);
        }

    }
    $(function () {
        _firstTimeAttach = true;
        Init();
    });

})(jQuery);
```


##License

The MIT License (MIT)

Copyright (c) 2015 [Mobidev](http://mobidev.biz/)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.# Pager
